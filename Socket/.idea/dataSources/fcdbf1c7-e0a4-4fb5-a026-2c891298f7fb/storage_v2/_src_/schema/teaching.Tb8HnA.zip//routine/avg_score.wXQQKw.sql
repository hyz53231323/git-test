create
    definer = root@localhost procedure avg_score(IN c_no char(6))
begin
select courseno,avg(final)
from score
where courseno=c_no;
end;

