create
    definer = root@localhost procedure update_cno()
begin
start transaction;
update course set cname = '高等数学'
where courseno = 'c05103';

commit;
select * from course where courseno = 'c05103';
end;

