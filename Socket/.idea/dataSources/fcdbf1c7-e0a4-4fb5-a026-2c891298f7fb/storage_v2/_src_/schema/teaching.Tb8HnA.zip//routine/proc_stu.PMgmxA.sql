create
    definer = root@localhost procedure proc_stu() reads sql data
begin
select studentno,sname,birthdate,phone
from student
where phone like ' 131% ' order by studentno;
end;

