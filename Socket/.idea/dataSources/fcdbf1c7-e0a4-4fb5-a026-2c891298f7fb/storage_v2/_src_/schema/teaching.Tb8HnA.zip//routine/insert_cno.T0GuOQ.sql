create
    definer = root@localhost procedure insert_cno()
begin
start transaction;
insert into course
values('c05141','WIN设计','选修',32,8,8);
insert into course
values('c05142','WEB语言','选修',48,8,8);
select * from course where term =8;
commit;
end;

