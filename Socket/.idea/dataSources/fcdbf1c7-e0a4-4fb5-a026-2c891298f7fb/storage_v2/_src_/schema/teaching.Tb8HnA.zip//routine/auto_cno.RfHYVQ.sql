create
    definer = root@localhost procedure auto_cno()
begin
start transaction;
delete from course where courseno = 'c05103';
select * from course where courseno = 'c05103';
rollback;
select * from course where courseno ='c05103';
end;

