create
    definer = root@localhost procedure select_score(IN s_no char(11), IN c_no char(6))
begin
select * from score
where studentno = s_no and courseno = c_no;
end;

