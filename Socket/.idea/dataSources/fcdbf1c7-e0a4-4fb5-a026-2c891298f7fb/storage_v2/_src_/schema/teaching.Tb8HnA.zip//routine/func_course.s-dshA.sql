create
    definer = root@localhost function func_course(c_no varchar(6)) returns char(6)
    comment 'find function name'
    reads sql data
begin
  return (select cname from course
where courseno=c_no);
end;

