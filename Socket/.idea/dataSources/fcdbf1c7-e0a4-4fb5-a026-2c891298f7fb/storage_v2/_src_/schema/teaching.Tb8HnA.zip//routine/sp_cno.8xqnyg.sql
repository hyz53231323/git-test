create
    definer = root@localhost procedure sp_cno()
begin
start transaction;
insert into course
values('c05139','建模UML','选修',48,12,7);
savepoint spcno1;
delete from course
where courseno = 'c05139';
rollback work to savepoint spcno1;
select * from course where courseno = 'c05139';
commit;
end;

