create
    definer = root@localhost procedure trans_bank()
begin
declare money decimal(13,2);
start transaction;
update bank set cur_money = cur_money - 1000 where cus_no = 'bj101211';
update bank set cur_money = cur_money + 1000 where cus_no = 'sd101677';
select cur_money into money from bank where cus_no = 'bj101211';
if money < 1 then
begin
select 'The transaction fails,the rollback transaction';
rollback;
end;
else
begin
select 'A successful transaction,commits the transaction';
commit;
end;
end if;
end;

